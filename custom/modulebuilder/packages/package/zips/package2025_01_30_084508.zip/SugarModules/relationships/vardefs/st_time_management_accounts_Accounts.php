<?php
// created: 2025-01-30 08:45:08
$dictionary["Account"]["fields"]["st_time_management_accounts"] = array (
  'name' => 'st_time_management_accounts',
  'type' => 'link',
  'relationship' => 'st_time_management_accounts',
  'source' => 'non-db',
  'module' => 'st_time_management',
  'bean_name' => 'st_time_management',
  'side' => 'right',
  'vname' => 'LBL_ST_TIME_MANAGEMENT_ACCOUNTS_FROM_ST_TIME_MANAGEMENT_TITLE',
);
