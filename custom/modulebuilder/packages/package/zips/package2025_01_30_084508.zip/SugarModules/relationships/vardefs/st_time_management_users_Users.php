<?php
// created: 2025-01-30 08:45:08
$dictionary["User"]["fields"]["st_time_management_users"] = array (
  'name' => 'st_time_management_users',
  'type' => 'link',
  'relationship' => 'st_time_management_users',
  'source' => 'non-db',
  'module' => 'st_time_management',
  'bean_name' => 'st_time_management',
  'side' => 'right',
  'vname' => 'LBL_ST_TIME_MANAGEMENT_USERS_FROM_ST_TIME_MANAGEMENT_TITLE',
);
